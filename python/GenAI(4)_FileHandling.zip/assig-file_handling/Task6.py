prices = {
    "Mouse": 500,
    "Keyboard": 800,
    "Monitor": 7000,
    "Pendrive": 400,
    "Camera": 5000
}

# Ask for discount
discount = float(input("Enter discount percentage: "))

discounted_prices = []

# Open file in write mode
file = open("discount.txt", "w")

file.write("Product | Original Price | Discounted Price\n")

for product, price in prices.items():

    discounted_price = price - (price * discount / 100)

    discounted_prices.append(discounted_price)

    file.write(f"{product} | {price} | {discounted_price:.2f}\n")


# Calculate summary
total_items = len(prices)
average_price = sum(discounted_prices) / total_items

file.write("\n")
file.write(f"Total items : {total_items}\n")
file.write(f"Average discounted price : {average_price:.2f}\n")

file.close()


# Read and print the file
file = open("discount.txt", "r")

print(file.read())

file.close()